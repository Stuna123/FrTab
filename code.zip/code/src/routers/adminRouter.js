const express = require('express')
const debug = require('debug')('app:adminRouter')
const { MongoClient } = require('mongodb')
const sessions = require('../data/sessions.json')

const adminRouter = express.Router()

// On crée notre route
adminRouter.route('/').get((req, res) => {
    //url of mongoDB
    const url = 
    'mongodb+srv://dbUser:FoKX9x8EPhgmk1l3@globalmantics.inr5jcb.mongodb.net/?retryWrites=true&w=majority';

    const dbName = 'globalmantics'; 

    // use async/await in our data base
    (async function mongo() {
        let client;
        try {
            // we create our connection
            client = await MongoClient.connect(url);
            console.log('Connected to the mongo DB');

            const db = client.db(dbName);   

            const response = await db.collection('sessions').insertMany(sessions);
            res.json(response)

        } catch (error) {
            // show our error
            console.log(error.stack);
        }
        client.close();
    })();
});

module.exports = adminRouter
