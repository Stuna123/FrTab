const express = require('express')
const debug = require('debug')('app:sessionRouter');
const { MongoClient, ObjectId } = require('mongodb');
const speakerService = require('../services/speakerService')

const sessions = require('../data/sessions.json')

const sessionsRouter = express.Router()

// next dans le middleware c'est pour faire tout ce qu'il va avec
sessionsRouter.use((req, res, next) => {
    // si on laisse passé un utilisateur, on execute ce qui vient après sinon il se dirige vers l'authentification
    if(req.user) {
        next()
    } else {
        // pas d'authentification, on ne peut pas acceder à la page session
        // redirection vers l'authentification
        res.redirect('/auth/signIn')
    }
})

sessionsRouter.route('/')
    .get((req, res) => {

        const url =
        'mongodb+srv://dbUser:FoKX9x8EPhgmk1l3@globalmantics.inr5jcb.mongodb.net/?retryWrites=true&w=majority'
        const dbName = 'globalmantics';
      
        (async function mongo() {    
          let client;
          try {
            client = await MongoClient.connect(url);
            debug('Connected to the mongo DB');
      
            const db = client.db(dbName);
      
            const sessions = await db.collection('sessions').find().toArray();
            res.render('sessions', {sessions});
          } catch (error) {
            debug(error.stack);
          }
          client.close();
        })();
})

// anytime we get something with an ID
sessionsRouter.route('/:id')
    .get((req, res) => {
        const id = req.params.id

        const url =
        'mongodb+srv://dbUser:FoKX9x8EPhgmk1l3@globalmantics.inr5jcb.mongodb.net/?retryWrites=true&w=majority'
        const dbName = 'globalmantics';
      
        (async function mongo() {    
          let client;
          try {
            client = await MongoClient.connect(url);
            debug('Connected to the mongo DB');
      
            const db = client.db(dbName);
      
            const session = await db.collection('sessions').findOne({_id: new ObjectId(id)});
            const speaker = await speakerService.getSpeakerById(session.speakers[0].id)
            session.speaker = speaker.data

            res.render('session', {
                session,
            })

          } catch (error) {
            debug(error.stack);
          }
          client.close();
        })();
})

module.exports = sessionsRouter