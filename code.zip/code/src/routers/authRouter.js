const express = require('express')
const debug = require('debug')('app:sessionRouter')
const { MongoClient, ObjectID } = require('mongodb')
const passport = require('passport')
const authRouter = express.Router()

authRouter.route('/signUp').post((req,res) => {
    const { username, password } = req.body
    const url =
    'mongodb+srv://dbUser:FoKX9x8EPhgmk1l3@globalmantics.inr5jcb.mongodb.net/?retryWrites=true&w=majority'
    const dbName = 'globalmantics';

    // create a user
    (async function addUser(){
        let client;
        try {
            client = await MongoClient.connect(url)

            const db = client.db(dbName)
            const user = { username, password }
            const results = await db.collection('users').insertOne(user)
            debug(results)
            req.login(results.ObjectID[0], () => {
                res.redirect('/auth/profile')
            })
            
        } catch (error) {
            debug(error)
        }
        client.close()
    }())

    req.login(req.body, () => {
        res.redirect('/auth/profile')
    })
})

authRouter.route('/signIn').get((req, res) => {
    res.render('signin')
})
.post(passport.authenticate('local', {
    successRedirect: '/auth/profile',
    failureMessage: '/',
}))

authRouter.route('/profile').get((req, res) => {
    res.json(req.user)
})
module.exports = authRouter