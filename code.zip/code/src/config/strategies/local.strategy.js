// This is where wr'ere going to put all of our code associated with our local.strategy
const passport = require('passport')
const { Strategy } = require('passport-local')
const { MongoClient } = require('mongodb')
const debug = require('debug')('app:localStrategy')

/**
 * When you're using the local.strategy, this is the method (the code below) 
 * you're going to call to figure out whether or not somebody can be logged in.
 */
module.exports = function localStrategy() {
    /** 
     * This function take two information
     * The information will be send to a function
     * */
    passport.use(new Strategy({
        // the information from our form which is in the index.ejs
        usernameField: 'username',
        passwordField: 'password',
    },
    // we get our information from passport
        (username, password, done) => {
            // we use a database
            const url =
            'mongodb+srv://dbUser:FoKX9x8EPhgmk1l3@globalmantics.inr5jcb.mongodb.net/?retryWrites=true&w=majority';
            const dbName = 'globalmantics';

            (async function validateUser(){
                let client
                try {
                    client = await MongoClient.connect(url)
                    debug('Connected to the mongo DB')
                    const db = client.db(dbName)

                    // we are going to find our user by his name (username)
                    const user = await db.collection('users').findOne({username});

                    // test if the user exist (if terniaire)
                    (user && user.password === password) ? done(null, user) : done(null, false);

                } catch (error) {
                    // we do not have a user
                    done(error, false)
                }
            }())
        }))
}